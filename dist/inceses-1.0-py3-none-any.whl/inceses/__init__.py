## İnceses - Turkish Phonetic Transcriptor
## by: Enis Tuna

from .main import phonetic_analysis

__all__ = ['phonetic_analysis']